package automation;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageobjects.AutomationloginTest;
import pageobjects.AutomationsigninTest;
import pageobjects.MegamenuTest;
import pageobjects.SelectdressTest;
import resources.browserTest;


@Test
	public class LaunchautomationTest extends browserTest {
		
	@BeforeTest
		public void launch()  throws IOException, InterruptedException
		{
		
		driver=initialization();
		Thread.sleep(5000);
		
	}
		public void Assignin()
		{
			AutomationsigninTest s = new AutomationsigninTest(driver);
			s.Signinmeth().click();

	}
		public void Blogin()
		{
			AutomationloginTest lp=new AutomationloginTest(driver);
			lp.UserName().sendKeys("sripuja.ece@gmail.com");
			lp.pwd().sendKeys("Password@123");
			lp.Submit().click();
		}
		public void cdresses()
		{
			MegamenuTest mm=new MegamenuTest(driver);
			mm.Dresses().click();
			mm.Summerdresses().click();
	}
		public void dpick()
		{
			SelectdressTest sd=new SelectdressTest(driver);
			sd.Firstdress().click();
			sd.Bluedress().click();
			sd.Cart().click();
			
			String testName = sd.Name().getText();
			System.out.println(testName);
			String testcolor = sd.Color().getText();
			System.out.println(testcolor);
			String testquantity = sd.Quantity().getText();
			System.out.println(testquantity);
			
	}
}

