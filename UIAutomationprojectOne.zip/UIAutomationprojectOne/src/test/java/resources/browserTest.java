package resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class browserTest {
public WebDriver driver;

	public WebDriver initialization() throws IOException {
        Properties prop = new Properties();
		FileInputStream fs = new FileInputStream(
				"C:\\Users\\777633\\eclipse-workspace\\UIAutomation\\src\\test\\java\\resources\\data.properties");
		prop.load(fs);
		String browsername = prop.getProperty("browser");
		if (browsername.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\777633\\\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(prop.getProperty("url"));
		}
		return driver;
	}
}
