package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AutomationloginTest {
	WebDriver driver;

	public AutomationloginTest(WebDriver driver) {
		this.driver = driver;
	}
		//username and password
		By username=(By.id("email"));
		By password=(By.id("passwd"));
		By submit=(By.cssSelector("#SubmitLogin > span"));
	
		
		public WebElement UserName()
		{
			return driver.findElement(username);
		}
		public WebElement pwd() {
			return driver.findElement(password);
		}
		public WebElement Submit() {
			return driver.findElement(submit);
		}
	}

