package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SelectdressTest {

	WebDriver driver;

	public SelectdressTest (WebDriver driver) {
		this.driver = driver;
	}
	By firstdress=(By.partialLinkText("http://automationpractice.com/index.php?id_product=5&controller=product"));
	By bluedress=(By.partialLinkText("http://automationpractice.com/index.php?id_product=5&controller=product"));
	By addcart=(By.cssSelector("#add_to_cart > button > span"));
	By name=(By.id("layer_cart_product_title"));
	By color= By.id("layer_cart_product_attributes");
	By quantity=By.id("layer_cart_product_quantity");
	
	public WebElement Firstdress()
	{
		return driver.findElement(firstdress);
	}
	public WebElement Bluedress() {
		return driver.findElement(bluedress);
	}
	public WebElement Cart() {
		return driver.findElement(addcart);
	}
	public WebElement Name() {
		return driver.findElement(name);
	}
	public WebElement Color() {
		return driver.findElement(color);
	}
	public WebElement Quantity() {
		
		return driver.findElement(quantity);
	}
}

