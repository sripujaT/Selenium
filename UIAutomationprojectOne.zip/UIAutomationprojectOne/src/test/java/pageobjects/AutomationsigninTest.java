package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AutomationsigninTest {

	WebDriver driver;
	By sign = By.cssSelector("#header > div.nav > div > div > nav > div.header_user_info > a");

	public AutomationsigninTest (WebDriver driver) {
		this.driver = driver;
	}

	public WebElement Signinmeth() {
		return driver.findElement(sign);
	}
}
