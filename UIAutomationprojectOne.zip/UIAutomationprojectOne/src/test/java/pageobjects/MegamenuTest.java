package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MegamenuTest {
	WebDriver driver;

	public MegamenuTest (WebDriver driver) {
		this.driver = driver;
	}
	By dresses=(By.cssSelector("#block_top_menu > ul > li:nth-child(2) > a"));
	By summerdresses=(By.cssSelector("#categories_block_left > div > ul > li.last > a"));
	public WebElement Dresses()
	{
		return driver.findElement(dresses);
	}
	public WebElement Summerdresses() {
		return driver.findElement(summerdresses);
	}
}
