package stepdefinpackage;

import org.testng.AssertJUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.SelectdressTest;
import resources.browserTest;

public class stepdefinTest extends browserTest {
	WebDriver driver;

    @Given("^Initialize the chrome browser$")
    public void initialize_the_chrome_browser() throws Throwable {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\777633\\chromedriver.exe");
    	driver=new ChromeDriver();
    	driver.get("http://automationpractice.com/");
    	driver.manage().window().maximize();
    	System.out.println("launches the Chrome");
    }

    @When("^click on signin$")
    public void click_on_signin() throws Throwable {
    	driver.findElement(By.cssSelector("#header > div.nav > div > div > nav > div.header_user_info > a")).click();
    	Thread.sleep(1000);
    	System.out.println("clicks on signin");
    	 Thread.sleep(2000);
    	}
    @Then("^user enters username and password$")
    public void user_enetrs_username_and_password() throws Throwable {
    	driver.findElement(By.name("email")).sendKeys("sripuja.ece@gmail.com");
    	driver.findElement(By.name("passwd")).sendKeys("Password@123");
    	 Thread.sleep(2000);
    }
    
    @Then("^click login$")
    public void click_login() throws Throwable {
    	WebElement loginbutton=driver.findElement(By.name("SubmitLogin"));
    	JavascriptExecutor js=(JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();",loginbutton);
    	 Thread.sleep(2000);
    }
    
    @Then("^click on Dresses$")
    public void click_on_dresses() throws Throwable {
    	 driver.findElement(By.cssSelector("#block_top_menu > ul > li:nth-child(2) > a")).click();
    	 Thread.sleep(2000);
    	System.out.println("clicks on dresses button");
    }

    @Then("^click on summer dresses$")
    public void click_on_summer_dresses() throws Throwable {
    	driver.findElement(By.cssSelector("#categories_block_left > div > ul > li.last > a")).click();
    	System.out.println("clicks on summer dresses button");
    	 Thread.sleep(2000);
    }
    
    @Then("^click on sort by price$")
    public void click_on_sort_by_price() throws Throwable {
    	driver.findElement(By.cssSelector("#selectProductSort")).click();
    	System.out.println("displays the sort by price list");
    	 Thread.sleep(2000);
    }
    
    	@Then("^validate the grid$")
        public void validate_the_grid() throws Throwable {
        	SoftAssert sa=new SoftAssert();
    	driver.getTitle();
    	sa.assertEquals("grid", "title");
    	System.out.println("grid is validated");
        Thread.sleep(2000);
       }

    
    @Then("^click on title Printed Summer Dress$")
    public void click_on_title_Printed_Summer_Dress() throws Throwable {
    driver.findElement(By.cssSelector("a[title*='Printe']")).click();
    Thread.sleep(2000);
    	System.out.println("selects a  dress");
    }


    @Then("^click the color Blue$")
    public void click_the_color_blue() throws Throwable {
    	driver.get("http://automationpractice.com/index.php?id_product=5&controller=product#/size-s/color-blue");
    	driver.findElement(By.cssSelector("#color_14")).click();
    	 Thread.sleep(1000);
    	 System.out.println("displays blue dress");
    }

    @Then("^click add to the cart$")
    public void click_add_to_the_cart() throws Throwable {
    	WebElement addToCart = driver.findElement(By.cssSelector("#add_to_cart > button > span"));
    	 addToCart.click();
    	 System.out.println("Product, quantity and color are successfully added to the cart summary page");
    	 Thread.sleep(2000);
    	 }
    //validation
    @Then("^Printed Summer Dress added to shopping cart$")
    public void printed_summer_dress_added_to_shopping_cart() throws Throwable {
    	SelectdressTest st = new SelectdressTest(driver);
    	String nameTest = st.Name().getText();
    	System.out.println(nameTest);
    
    }

    @Then("^Blue s color  added to shopping cart$")
    public void blue_s_color_added_to_shopping_cart() throws Throwable {
    	SelectdressTest st = new SelectdressTest(driver);
    	String colorTest = st.Color().getText();
    	System.out.println(colorTest);
  	
    }

    @Then("^Quantity 1 added to shopping cart$")
    public void Quantity_1_added_to_shopping_cart() throws Throwable {
    	
    	SelectdressTest st = new SelectdressTest(driver);
    	String quantityTest = st.Quantity().getText();
    	System.out.println(quantityTest);
    	
    	SoftAssert sa=new SoftAssert();
//    	String title= driver.getTitle();
//    	sa.assertEquals(Quantity, title);
//    	System.out.println("quantity successfully added to the cart");
//        Thread.sleep(2000);
        sa.assertAll();
    }
    @Given("^launch the firefox browser$")
    public void launch_the_firefox_browser() throws Throwable {
    	System.out.println("Before launch Firefox");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\777633\\geckodriver.exe");
    	driver=new FirefoxDriver();
    	System.out.println("After launch Firefox");
    	driver.get("http://automationpractice.com/");
    	System.out.println("Navigated to automationpractice.com");
    	driver.manage().window().maximize();
    	System.out.println("launches the Firefox");
    }
    
    }
    






